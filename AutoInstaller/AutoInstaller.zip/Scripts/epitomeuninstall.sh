#!/bin/bash

rm -rf ~/Epitome/ 

rm -rf ~/tempepitome 

rm -rf ~/EpitomeVE 

exit
