#!/bin/bash

xdg-open http://localhost:8000/user/login
