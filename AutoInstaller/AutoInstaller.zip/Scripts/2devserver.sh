#!/bin/bash

source ~/EpitomeVE/bin/activate

cd ~/Epitome 

python3 manage.py runserver
